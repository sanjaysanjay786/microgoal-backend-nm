require("dotenv").config();

const express = require("express");
const app = express();

const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");

const errormiddleware = require("./Middlewares/errormiddleware");
const authRoute = require("./Router/AuthRouter");
const GoalRouter = require("./Router/GoalRouter");

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Environment variables
const PORT = process.env.PORT || 8000;
const Mongo_Url = process.env.MONGO_URL;

// MongoDB connection
mongoose
  .connect(Mongo_Url, {
    serverSelectionTimeoutMS: 30000,
  })
  .then(() => {
    console.log("MongoDB Connected");
  })
  .catch((err) => {
    console.log("Detailed Error Output:");
    console.dir(err);
  });

// Routes
app.use("/", authRoute);
app.use("/", GoalRouter);

// Error Middleware
app.use(errormiddleware);

// Server start
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});